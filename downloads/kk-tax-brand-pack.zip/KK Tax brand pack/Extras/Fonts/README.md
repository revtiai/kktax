# KK Tax fonts

| Font | Use | Licence | Source |
|---|---|---|---|
| Newsreader | Every headline | SIL Open Font Licence 1.1 | https://fonts.google.com/specimen/Newsreader |
| Inter | Body text and interface | SIL Open Font Licence 1.1 | https://fonts.google.com/specimen/Inter · https://rsms.me/inter |
| Gloock | Basis of the wordmark artwork only | SIL Open Font Licence 1.1 | https://fonts.google.com/specimen/Gloock |

All three are free for commercial use in print, on the web, in documents and in logos. They may be embedded in PDFs and self-hosted. The licence texts are in this folder.

- **Desktop (install these):** TTF files for Word, PowerPoint, Keynote, Figma or InDesign. On a Mac, double-click a file and choose Install.
- **Web (woff2):** Inter files for the web. The website installs Newsreader and Inter through its own packages and makes no Google Fonts request.
- **Fallback:** where the fonts are not available (email signatures, shared Office files), use Georgia for headings and Arial for text.

The wordmark is outlined vector artwork. Do not retype the name in Gloock; use the supplied logo files.
